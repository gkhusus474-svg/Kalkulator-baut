# Kalkulator Baut — BY RIZKY ABDILAH

Aplikasi Android offline untuk estimasi jumlah baut, mur, ring, dan barang kecil dari berat.

## Fitur
- Estimasi jumlah PCS berdasarkan berat total dan data acuan.
- Kalkulator berat rata-rata per PCS.
- Data barang tersimpan lokal.
- Riwayat perhitungan tersimpan lokal.
- Antarmuka premium hitam/abu-abu dengan aksen kuning industrial.
- Tidak meminta izin internet; data disimpan di perangkat.

## Cara membuat APK di Android Studio
1. Instal Android Studio versi stabil dari https://developer.android.com/studio
2. Ekstrak ZIP ini.
3. Android Studio → **Open** → pilih folder `Kalkulator_Baut_BY_RIZKY_ABDILAH` hasil ekstrak.
4. Tunggu proses Gradle Sync. Jika diminta, instal Android SDK Platform 35 dan gunakan JDK 17 yang disediakan Android Studio.
5. Untuk mencoba aplikasi: tekan tombol **Run ▶** dan pilih emulator/HP Android dengan USB debugging aktif.
6. Untuk membuat APK yang bisa dipasang: menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. Setelah selesai, klik **locate** pada notifikasi hasil build. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.
8. Pindahkan APK ke HP dan buka file tersebut. Jika diminta, izinkan instalasi dari sumber tersebut di pengaturan Android.

## Cara pakai kalkulator
Misalnya berat total 2,612 kg. Diketahui 1.000 PCS memiliki berat acuan 0,500 kg.
Masukkan total `2,612`, acuan `0,500`, PCS acuan `1000`. Hasil estimasi sekitar 5.224 PCS.

**Penting:** hasil adalah estimasi berdasarkan berat rata-rata. Perbedaan ukuran, toleransi produksi, kotoran, dan ketelitian timbangan bisa memengaruhi hasil. Timbang sampel yang representatif untuk hasil terbaik.

## Catatan teknis
- Proyek menggunakan Android WebView dan file HTML lokal di `app/src/main/assets/index.html`.
- Penyimpanan menggunakan `localStorage` WebView; data tidak tersinkron ke perangkat lain. Menghapus data aplikasi dapat menghapus data tersimpan.
- `gradlew` wrapper tidak disertakan; Android Studio dapat mengimpor proyek Gradle dan membuat/menyediakan wrapper sesuai konfigurasi lokal.

## Build APK lewat HP tanpa komputer (GitHub Actions)
1. Ekstrak ZIP ini di HP.
2. Buat repository baru di https://github.com/new, beri nama `kalkulator-baut`, pilih **Public** agar paling mudah mengikuti langkah ini, lalu buat repository. Jangan unggah password atau data pribadi.
3. Dari halaman repository, pilih **Add file → Upload files**. Unggah isi folder proyek (bukan file ZIP-nya), termasuk file tersembunyi `.github/workflows/android.yml`. Jika situs mobile sulit menangani folder bertingkat, aktifkan **Situs desktop** di menu Chrome.
4. Tekan **Commit changes**.
5. Buka tab **Actions** di repository, pilih workflow **Build Kalkulator Baut APK**, lalu tekan **Run workflow** jika belum berjalan otomatis.
6. Tunggu sampai job selesai dengan tanda centang hijau. Buka hasil run tersebut, gulir ke **Artifacts**, lalu unduh `Kalkulator-Baut-APK`.
7. File artefak yang diunduh berbentuk ZIP. Ekstrak ZIP itu, cari `app-debug.apk`, lalu buka untuk memasang. Android mungkin meminta izin **Install unknown apps** untuk Chrome/Files; izinkan hanya jika file berasal dari workflow repository milikmu sendiri.
8. GitHub Actions artifact biasanya tersedia terbatas waktunya, jadi simpan APK di HP setelah mengunduh.

Catatan: workflow menggunakan GitHub Actions untuk mengompilasi di cloud. Repository publik berarti kode sumber dapat dilihat orang lain; jangan masukkan rahasia atau informasi pribadi. Alur antarmuka GitHub mobile dapat berubah.
